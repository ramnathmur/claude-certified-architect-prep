CCA-F PRACTICE TEST KIT
=======================

Generates full-length practice exams for the Anthropic Claude Certified
Architect - Foundations certification (official exam code CCAR-F), on your
own machine, using your own Claude subscription.

Each generated test is one self-contained HTML file: 60 questions in four
scenario blocks, four options each, and a written explanation of why the
right answer is right and why each wrong one is wrong, with a citation into
the corpus. It opens in any browser. Nothing is installed, and nothing you
do in it is sent anywhere.


WHAT YOU NEED
-------------

Claude Code on this machine, signed in with your own Claude subscription.
That is all. No API key, no Python (it helps, it is not required), no
network access beyond Claude itself.


HOW TO SET IT UP - THREE STEPS
------------------------------

1. Extract this whole zip to a folder you can find again, for example
   C:\CCA-F-Kit
   Keep all the files together in one folder.

2. Open Claude Code with that folder as its working directory.

3. Open 1-INSTALL-PROMPT.md, copy everything below the horizontal line,
   and paste it into Claude Code.

The installer checks the files are intact, extracts the test renderer,
registers a /cca-exam command, and tells you what it found. It takes about
a minute and touches nothing outside the folder.


HOW TO GENERATE A TEST
----------------------

Restart Claude Code in the kit folder, then type:

    /cca-exam

The restart matters - Claude Code only picks up the new command when it
starts. Then answer the few questions it asks.

Generating a full paper takes 20 to 40 minutes and writes 60 questions with
240 explanations, so start it when you have the session free. The finished
file lands in the tests\ subfolder. Double-click it.


WHAT IS IN THIS ZIP
-------------------

README-FIRST.txt                 this file
1-INSTALL-PROMPT.md              paste into Claude Code to set up
2-GENERATE-TEST-PROMPT.md        the generator, with the renderer inside it
CCA-F_Generator-Corpus_v1.md     the source material - 73 numbered sections


USING THE TEST
--------------

Hint mode ON turns the paper into a teaching session: the answer and all
four explanations appear the moment you pick an option. Best the first time
through, and the fastest way to find out what you do not know.

Hint mode OFF runs it as the real thing: a 120-minute countdown with
everything withheld until you submit.

Your answers and timings are saved in the browser, so you can stop partway
and come back. The results card breaks your score down by domain and by
block, estimates a scaled score against the 720 pass line, and gives you a
"Copy results JSON" button.


A FEW HONEST CAVEATS
--------------------

These are practice questions, not real exam questions. Nobody involved has
seen the live exam. They are written from a corpus built against Anthropic's
published Exam Guide.

This kit is not affiliated with, endorsed by, or sponsored by Anthropic.

The corpus was written against Exam Guide v0.2 and re-checked against v1.0
(effective July 2026). The domain weights, all six scenarios, all thirty
task statements and both scope lists were identical between the two
versions. Even so, confirm anything decision-critical against the guide
currently published on the Anthropic Partner Academy.

Explanations cite corpus sections as "Corpus S1.6". Those are plain text,
not links - look the section up by its number in
CCA-F_Generator-Corpus_v1.md.

The test page loads three fonts from Google Fonts. On a network that blocks
that, everything still works and the type falls back to a system font.
Nothing else touches the network.
